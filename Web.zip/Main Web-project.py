from flask import Flask, url_for, request, render_template, redirect
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField
from wtforms.validators import DataRequired
import sqlite3

app = Flask(__name__)


class DB:
    def __init__(self):
        conn = sqlite3.connect('news.db', check_same_thread=False)
        self.conn = conn

    def get_connection(self):
        return self.conn

    def __del__(self):
        self.conn.close()


newsdb = DB()


class AddNewsForm(FlaskForm):
    title = StringField('Заголовок новости', validators=[DataRequired()])
    content = TextAreaField('Текст новости', validators=[DataRequired()])
    submit = SubmitField('Добавить')


class NewsModel:
    def __init__(self, connection):
        self.connection = connection
        self.init_table()

    def init_table(self):
        cursor = self.connection.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS news 
                            (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                             title VARCHAR(100),
                             content VARCHAR(1000)
                             )''')
        cursor.close()
        self.connection.commit()

    def insert(self, title, content):
        cursor = self.connection.cursor()
        try:
            cursor.execute('''INSERT INTO news 
                          (title, content) 
                          VALUES (?,?)''', (title, content))
            cursor.close()
            self.connection.commit()
            temp = self.get_all()
            print(temp)
        except Exception as e:
            print(e)

    def get(self, news_id):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM news WHERE id = ?", (str(news_id),))
        row = cursor.fetchone()
        return row

    def get_all(self):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM news")
        rows = cursor.fetchall()
        return rows

    def delete(self, news_id):
        cursor = self.connection.cursor()
        cursor.execute('''DELETE FROM news WHERE id = ?''', (str(news_id),))
        cursor.close()
        self.connection.commit()


admin_username = '123'
admin_password = '321'
app.config['SECRET_KEY'] = 'school_17_sar'

flag = False


class LoginForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    submit = SubmitField('Войти')


@app.route('/')
@app.route('/main')
def main():

    return render_template('main.html', img=url_for('static', filename='img/school.jpg'), img1=url_for('static', filename='img/banner_ate.jpg'),
                           img2=url_for('static', filename='img/banner_dtd.jpg'), img3=url_for('static', filename='img/banner_gosusl.jpg'),
                           img4=url_for('static', filename='img/banner_edu.jpg'), img5=url_for('static', filename='img/banner_kos.jpg'),
                           img6=url_for('static', filename='img/banner_fadn.jpg'), img7=url_for('static', filename='img/banner_pk.jpg'),
                           img8=url_for('static', filename='img/banner_gdv.jpg'), img9=url_for('static', filename='img/banner_bus.jpg'),
                           img10=url_for('static', filename='img/banner_minpros.jpg'), img11=url_for('static', filename='img/banner_upr.jpg'),
                           img12=url_for('static', filename='img/banner_psa.jpg'), link1="http://saredu.ru/ATE22.php", link2="https://www.ya-roditel.ru/parents/helpline/",
                           link3="https://www.gosuslugi.ru", link4="http://www.edu.ru",
                           link5="http://www.sarkomobr.ru", link6="http://fadn.gov.ru", link7="https://saredu.ru/PK.php", link8="https://добровольцыроссии.рф",
                           link9="https://bus.gov.ru/pub/home", link10="https://edu.gov.ru", link11="http://дети-саратов.рф", link12="http://saratov.gov.ru")


@app.route('/docs')
def docs():
    return render_template("docs.html", img=url_for('static', filename='img/school.jpg'), link1='http://127.0.0.5:8080/main_docs',
                           link2='http://127.0.0.5:8080/structure', link3='http://127.0.0.5:8080/documents',
                           link4='http://127.0.0.5:8080/obraz', link5='http://127.0.0.5:8080/standarts',
                           link6='http://127.0.0.5:8080/administration', link7='http://127.0.0.5:8080/techno',
                         link11='http://127.0.0.5:8080/places',)


@app.route('/main_docs')
def main_docs():
    return render_template("main_docs.html", img=url_for('static', filename='img/school.jpg'),
                           link1='http://shkola17.saredu.ru/upload/doc/71550158601.pdf')


@app.route('/structure')
def structure():
    return render_template("structure.html", img=url_for('static', filename='img/school.jpg'),
                           link1='http://shkola17.saredu.ru/upload/doc/01508147642.pdf', link2='http://shkola17.saredu.ru/upload/doc/21508147582.pdf',
                           link3='https://docviewer.yandex.ru/?url=ya-browser%3A%2F%2F4DT1uXEPRrJRXlUFoewruLiYJXzjA66bQDU1T8sIE_jfDrRX5IJyd_fEYe2NU29O7gBmi9uexL2ScPteY3il3b6HBS4_1hYBcjGzg-gQdY9ijEElUIv2OtcOCba589BQCyRYnozE2IPMl00Sjtx4qw%3D%3D%3Fsign%3DHKVO_EtznG-RNGlHkO3Zlo95S4WP8O6mZxuTfmBM7Pw%3D&name=11455966001.doc',
                           link4='https://docviewer.yandex.ru/view/225467982/?*=rmiLmZ%2B24oDHMwRGqhOHFHWewi17InVybCI6InlhLWJyb3dzZXI6Ly80RFQxdVhFUFJySlJYbFVGb2V3cnVObmxCSmtkOUotSmduUE1MNHBFNzV1N1RYLXNXRFZLNzExUWtXZnRTdXl5TFg5eUlsWUpoelpqNWltZnZRSFAtbUZSWU53RkV4SzZQZUdrdVZ0UjFTLUU0OWpmUzA2dXZLUGtDYnhLMXRYM3ktMm5Md19DaGc0SHJQaVpEQVh0MFE9PT9zaWduPV9VV29kbmhuR0M4bThRSU9Eb29TUUpWUlBrX3RQcVhMU1l6eTBVMnBEWnM9IiwidGl0bGUiOiI5MTQ1NTk2NTk3NS5kb2MiLCJ1aWQiOiIyMjU0Njc5ODIiLCJ5dSI6IjMwNjc5MTM0MDE1MTc5ODc3MjUiLCJub2lmcmFtZSI6ZmFsc2UsInRzIjoxNTU0MTg1ODc3OTczfQ%3D%3D',
                           link5='https://docviewer.yandex.ru/view/225467982/?*=wMk%2F%2BhSDGaRNE4VvnblfGEyh%2BEF7InVybCI6InlhLWJyb3dzZXI6Ly80RFQxdVhFUFJySlJYbFVGb2V3cnVBR1I1NjV1VWNGZzdldUNmd2gyUkxZMXQyWFdGNzRUYUVaTzdydzJXMHpFOWFkT05QSkZlWXBxU29IZVdaaXQyR1pyUFA5cnpNV0NrMUVDbGphM0p6My1MTDNhdkszcHFtMERZbEs3TDVQNkZkNlhROGZXZU83SENrN3pXUk9xekE9PT9zaWduPWR5Wlozd1NObmIwVnBUSnAweE1SSjZMRU5KMDhCeWJwSFVqbHhGdmprUTA9IiwidGl0bGUiOiI4MTQ1NTk2NTkyMy5kb2MiLCJ1aWQiOiIyMjU0Njc5ODIiLCJ5dSI6IjMwNjc5MTM0MDE1MTc5ODc3MjUiLCJub2lmcmFtZSI6ZmFsc2UsInRzIjoxNTU0MTg1OTEzMzY2fQ%3D%3D',
                           link6='https://docviewer.yandex.ru/view/225467982/?*=u0iF%2FOr4O7GJu3A2NrN%2FCqbwgn17InVybCI6InlhLWJyb3dzZXI6Ly80RFQxdVhFUFJySlJYbFVGb2V3cnVMUFdndzNEUHczeVpjN0pyWUV3X2JuNHFTUTNQY0YyVDlSZ3gyN1lTbjk4dXVhd2UtREt2OWVSNUtVVXZTbHk5bXhVYVViRzcweWpQQ0J3SEE0WGZMYllOTjJnQjZ1MXAwalBFRTlCUWs5UEh2eGlibEUteE5uSlNOdHlBUWhDWGc9PT9zaWduPWFzZXl6a09yb0s5cDBacERDMDVkZ2wzcnpRaE1JUlZrRzZQeW5rczVEMG89IiwidGl0bGUiOiI1MTQ1NTk1ODU0OC5kb2MiLCJ1aWQiOiIyMjU0Njc5ODIiLCJ5dSI6IjMwNjc5MTM0MDE1MTc5ODc3MjUiLCJub2lmcmFtZSI6ZmFsc2UsInRzIjoxNTU0MTg1OTM5MjY5fQ%3D%3D',
                           link7='https://docviewer.yandex.ru/?url=ya-browser%3A%2F%2F4DT1uXEPRrJRXlUFoewruO6hPzB6LwVIks7fEjQri13kOTnhchV9vxg_QrfY5iVI7jsjYOs8vLs8inQEXqKFB6cagCL6Wweb6OcGtRGKHtaSIxMrojTFo9G_pt6_WutARma_drH3UBjI7Sd5oJY7hQ%3D%3D%3Fsign%3DGugGxUfe7JurilP03dHjChlXWBpGPB-Okge-nFd6eh8%3D&name=41455966111.doc')


@app.route('/documents')
def documents():
    return render_template("documents.html", img=url_for('static', filename='img/school.jpg'),
                           link1='http://shkola17.saredu.ru/upload/doc/41550662113.pdf',
                           link2='http://shkola17.saredu.ru/upload/doc/51550066270.pdf',
                           link3='http://shkola17.saredu.ru/upload/doc/71550044819.pdfGzg-',
                           link4='http://shkola17.saredu.ru/upload/doc/81536298750.pdf',
                           link5='http://shkola17.saredu.ru/upload/doc/71533049436.pdf',
                           link6='http://shkola17.saredu.ru/upload/doc/41524132561.pdf')


@app.route('/obraz')
def obraz():
    return render_template("obraz.html", img=url_for('static', filename='img/school.jpg'),
                           link1='http://shkola17.saredu.ru/upload/doc/61550066630.pdf',
                           link2='http://shkola17.saredu.ru/upload/doc/71550066316.pdf',
                           link3='http://shkola17.saredu.ru/upload/doc/71511095089.pdf',
                           link4='https://docviewer.yandex.ru/?url=ya-browser%3A%2F%2F4DT1uXEPRrJRXlUFoewruGR9S73dh0YMHjwXqS4tJF9jlvEy9BWaAnWG3_cgrWnZT4lQ5mmj-EV16xYxh9rPyeK9RKyFRXEmwnSBytYNDIeVnr8oS4UGqa8eFzwCFh0QjRmVn4Ff6idenK1Y4Cs-kA%3D%3D%3Fsign%3DN_N0S6_CU9q0VoNNidLjy3_MsRXbE_4Zz9cWp0_dBcw%3D&name=91511094017.xlsx')


@app.route('/standarts')
def standarts():
    return render_template("standarts.html", img=url_for('static', filename='img/school.jpg'),
                           link1='http://shkola17.saredu.ru/upload/doc/41508148111.pdf',
                           link2='http://shkola17.saredu.ru/upload/doc/11508148021.pdf')


@app.route('/administration')
def administration():
    return render_template("administration.html", img=url_for('static', filename='img/school.jpg'),
                           link1='http://shkola17.saredu.ru/upload/doc/11550497167.pdf',
                           link2='http://shkola17.saredu.ru/upload/doc/91550483077.pdf'
                           )


@app.route('/techno')
def techno():
    return render_template("techno.html", img=url_for('static', filename='img/school.jpg'),
                           link2='https://docviewer.yandex.ru/?url=ya-browser%3A%2F%2F4DT1uXEPRrJRXlUFoewruIZw9lTNi0vklDnX8QaEp-bIJXg_kkq2k4OoOYQ21np5EGUxSKftY83rHz1YCU5ekcTIcgSuy8km1kFigU-NIpGH7NjO1ivIxPmv3jAEZGhuhKt0-17fTmEjBQWKRF-joA%3D%3D%3Fsign%3DADh4Ctaea6DiuKo3KgQ5DwiA-C0GSqeWMiukpkTd4Ls%3D&name=31455108275.docx',
                           link3='https://docviewer.yandex.ru/?url=ya-browser%3A%2F%2F4DT1uXEPRrJRXlUFoewruPJmPsLDs4b9cQFD2e-YBxLMgrZzYIp-IMlFOGPr-WkQuA5Jk_aQojXZqqw6L5AON5qar1obgDbPhqPctX0fwVz4G8THw8VSlweGunOAJwLp2UWVfUYeEQ9oO5TVF_CBLA%3D%3D%3Fsign%3DDxNNdtpXy2w4tM5TxjvJQFPZHliADr0dJp-xcgF80_M%3D&name=11455107971.docx',
                           link4='https://docviewer.yandex.ru/?url=ya-browser%3A%2F%2F4DT1uXEPRrJRXlUFoewruKUPTgjy0Z0gyhUIKDma7nZK_tvrqN02rJ3Uc6_F7TRWUQS_fa66glONxCke6bQATTf5rfPg8rK9MfmUbk6AhuRX7mEWayuR9No4npHhx_lpcJarpPHkpP95_k9-_7_D3g%3D%3D%3Fsign%3D9s0XhKwt6zAZr68jJsnu1Gdh8HjjDr6riZwV53YGZTg%3D&name=21455107832.docx'
                           )


@app.route('/places')
def places():
    return render_template("places.html", img=url_for('static', filename='img/school.jpg'),
                           link1='http://shkola17.saredu.ru/upload/doc/21553067767.pdf',
                           link2='http://shkola17.saredu.ru/upload/doc/81553066159.pdf',
                           link3='http://shkola17.saredu.ru/upload/doc/91552719444.pdf',
                           link4='http://shkola17.saredu.ru/upload/doc/91552719195.pdf'
                           )


@app.route('/news')
def news():
    nm = NewsModel(newsdb.get_connection())
    temp = nm.get_all()
    print(temp)
    return render_template("news.html", img=url_for('static', filename='img/school.jpg'), temp=temp)


@app.route('/personal')
def personal():
    return render_template("personal.html", img=url_for('static', filename='img/school.jpg'),
                           img1=url_for('static', filename='img/Sukhova.jpg'), img2=url_for('static', filename='img/Zlotnikova.jpg'),
                           img3=url_for('static', filename='img/Davidova.jpg'), img4=url_for('static', filename='img/Glushko.jpg'),
                           img5=url_for('static', filename='img/Udina.jpg'),)


@app.route('/contact')
def contact():
    return render_template("contact.html", img=url_for('static', filename='img/school.jpg'))


@app.route('/history')
def history():
    return render_template("history.html", img=url_for('static', filename='img/school.jpg'))


@app.route('/admin', methods=['GET', 'POST'])
def admin():
    global flag
    if request.method == 'GET':
        return '''<!doctype html>
                        <html lang="en">
                          <head>
                            <meta charset="utf-8">
                            <meta name="viewport"
                            content="width=device-width, initial-scale=1, shrink-to-fit=no">
                            <link rel="stylesheet"
                            href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
                            integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
                            crossorigin="anonymous">
                            <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
                        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
                        crossorigin="anonymous"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
                        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
                        crossorigin="anonymous"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/js/bootstrap.min.js"
                        integrity="sha384-7aThvCh9TypR7fIc2HV4O/nFMVCBwyIUKL8XCtKE+8xgCgl/PQGuFsvShjr74PBp"
                        crossorigin="anonymous"></script>
                            <title>Вход в панель управления</title>
                          </head>
                          <body>
                            <h1 align="center">   Вход в панель управления <br></h1>
                            <form method="post">
                                <input type="text" class="form-control" id="login" placeholder="Введите логин" name="login">
                                <input type="password" class="form-control" id="password" placeholder="Введите пароль" name="password">
                                <button type="submit" class="btn btn-primary">Войти</button>
                            </form>
                          </body>
                        </html>'''

    elif request.method == 'POST':
        if str(request.form['login']) == admin_username and str(request.form['password']) == admin_password:
            flag = True
            return redirect('/admin_news')
        else:
            flag = False
            return 'Ошибка доступа'


@app.route('/admin_news')
def admin_news():
    if flag:
        return render_template('admin_news.html', img=url_for('static', filename='img/school.jpg'),
                               link1='http://127.0.0.5:8080/add_news', link2='http://127.0.0.5:8080/del_news')
    else:
        return 'Ошибка доступа'


@app.route('/add_news', methods=['GET', 'POST'])
def add_news():
    if flag:
        form = AddNewsForm()
        if form.validate_on_submit():
            title = form.title.data
            content = form.content.data
            nm = NewsModel(newsdb.get_connection())
            nm.insert(title, content)
            return redirect("/admin_news")
        return render_template('add_news.html', title='Добавление новости',
                               form=form, img=url_for('static', filename='img/school.jpg'))
    else:
        return 'Ошибка доступа'


@app.route('/del_news')
def del_news():
    if flag:
        return render_template('del_news.html', img=url_for('static', filename='img/school.jpg'))
    else:
        return 'Ошибка доступа'


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.5')
